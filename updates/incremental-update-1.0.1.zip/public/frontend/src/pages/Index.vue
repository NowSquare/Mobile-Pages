<template>
  <q-page class="flex bg-light-blue-8 text-white">
    <div class="fit self-center text-center">
    <span class="text-h2">Fast. Mobile. Content.</span>
    </div>
  </q-page>
</template>
<script>
export default {
  name: 'PageIndex',
  components: {
  },
  data () {
    return {
    }
  },
  mounted () {
  },
  watch: {
  },
  methods: {
  },
  computed: {
  }
}
</script>
<style>
</style>
